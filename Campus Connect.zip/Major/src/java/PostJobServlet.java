

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

@MultipartConfig(fileSizeThreshold = 1024 * 1024 * 2, // 2MB
                 maxFileSize = 1024 * 1024 * 10, // 10MB
                 maxRequestSize = 1024 * 1024 * 50) // 50MB
public class PostJobServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, java.io.IOException {
        String companyName = request.getParameter("companyName");
        String title = request.getParameter("title");
        String Description = request.getParameter("description");
        String location = request.getParameter("location");
        String salary = request.getParameter("salary");
        Part filePart = request.getPart("jobDocument");

        String fileName = null;
        String uploadPath = "C:/uploaded_jobs/"; // Change this path as per your server

        // File upload logic
        if (filePart != null && filePart.getSize() > 0) {
            fileName = System.currentTimeMillis() + "_" + filePart.getSubmittedFileName();
            File fileSaveDir = new File(uploadPath);
            if (!fileSaveDir.exists()) {
                fileSaveDir.mkdir();
            }
            File file = new File(uploadPath + fileName);
            try (InputStream fileContent = filePart.getInputStream();
                 FileOutputStream fos = new FileOutputStream(file)) {
                byte[] buffer = new byte[1024];
                int bytesRead;
                while ((bytesRead = fileContent.read(buffer)) != -1) {
                    fos.write(buffer, 0, bytesRead);
                }
            }
        }

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/major", "root", "mahi");

            String query = "INSERT INTO jobs (company_name, title, description, location, salary, document_path) VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement ps = con.prepareStatement(query);
            ps.setString(1, companyName);
            ps.setString(2, title);
            ps.setString(3, Description);
            ps.setString(4, location);
            ps.setString(5, salary);
            ps.setString(6, (fileName != null) ? (uploadPath + fileName) : null);
            
            int result = ps.executeUpdate();
            if (result > 0) {
                response.getWriter().println("Job posted successfully!");
            } else {
                response.getWriter().println("Failed to post job.");
            }

            ps.close();
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("Error: " + e.getMessage());
        }
    }
}