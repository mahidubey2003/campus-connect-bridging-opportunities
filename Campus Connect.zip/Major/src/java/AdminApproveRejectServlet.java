

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/AdminApproveRejectServlet")
public class AdminApproveRejectServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String type = request.getParameter("type"); // "student", "company", or "job"
        String action = request.getParameter("action"); // "approve" or "reject"
        int id = Integer.parseInt(request.getParameter("id"));

        if (type == null || action == null) {
            response.sendRedirect("adminPanel.jsp?error=Invalid Parameters");
            return;
        }

        String tableName = "";
        String newStatus = action.equals("approve") ? "Approved" : "Rejected";

        // Determine the table based on type
        if (type.equals("student")) {
            tableName = "student";
        } else if (type.equals("company")) {
            tableName = "company";
        } else if (type.equals("jobs")) {
            tableName = "jobs"; // Job posts table
        } else {
            response.sendRedirect("adminPanel.jsp?error=Invalid Type");
            return;
        }

        try {
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/major", "root", "mahi");
            PreparedStatement ps = con.prepareStatement("UPDATE " + tableName + " SET status = ? WHERE id = ?");
            ps.setString(1, newStatus);
            ps.setInt(2, id);
            ps.executeUpdate();
            con.close();

            response.sendRedirect("adminPanel.jsp?success=" + type + " " + newStatus);
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("adminPanel.jsp?error=Something Went Wrong");
        }
    }
}
