import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/StudentLoginServlet")
public class StudentLoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private static final String DB_URL = "jdbc:mysql://localhost:3306/major";
    private static final String DB_USER = "root";
    private static final String DB_PASS = "mahi";

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        String email = request.getParameter("email");
        String password = request.getParameter("password");

        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);

            // Check if email & password are correct and get status
            String query = "SELECT * FROM student WHERE email=? AND password=?";
            stmt = conn.prepareStatement(query);
            stmt.setString(1, email);
            stmt.setString(2, password);
            rs = stmt.executeQuery();

            if (rs.next()) {
                String status = rs.getString("status");

                if ("APPROVED".equals(status)) {
                    // If student is approved, create a session and redirect to dashboard
                    HttpSession session = request.getSession();
                    session.setAttribute("studentEmail", email);
                    session.setAttribute("studentName", rs.getString("name"));

                    response.sendRedirect("studentDashboard.jsp");
                } else {
                    // If not approved, show message
                    out.println("<script>alert('Your account is not approved yet. Please wait for admin approval.'); window.location.href='studentLogin.html';</script>");
                }
            } else {
                // If incorrect email/password
                out.println("<script>alert('Invalid Credentials! Try Again.'); window.location.href='studentLogin.html';</script>");
            }

        } catch (Exception e) {
            out.println("<script>alert('Error: " + e.getMessage() + "'); window.location.href='studentLogin.html';</script>");
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
