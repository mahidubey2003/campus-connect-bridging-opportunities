import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.json.JSONArray;
import org.json.JSONObject;

@WebServlet("/FetchApprovedJobsServlet")
public class FetchApprovedJobsServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/major", "root", "mahi");

            String query = "SELECT id, company_name, title, location, salary FROM jobs WHERE status = 'Approved'";
            PreparedStatement ps = con.prepareStatement(query);
            ResultSet rs = ps.executeQuery();

            JSONArray jobArray = new JSONArray();

            while (rs.next()) {
                JSONObject job = new JSONObject();
                job.put("id", rs.getInt("id"));
                job.put("company", rs.getString("company_name"));
                job.put("title", rs.getString("title"));
                job.put("location", rs.getString("location"));
                job.put("salary", rs.getString("salary"));
                jobArray.put(job);
            }

            out.print(jobArray.toString());
            out.flush();

            rs.close();
            ps.close();
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            out.print("{\"error\": \"Something went wrong!\"}");
        }
    }
}

