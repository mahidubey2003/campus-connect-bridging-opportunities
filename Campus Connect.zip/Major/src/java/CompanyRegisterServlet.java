
import java.io.IOException;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/CompanyRegisterServlet")
public class CompanyRegisterServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String contact = request.getParameter("contact");
        String password = request.getParameter("password");

        Connection con = null;
        PreparedStatement checkStmt = null;
        PreparedStatement insertStmt = null;

        try {
            // Load JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish connection
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/major", "root", "mahi");

            // Check if the email is already registered
            String checkQuery = "SELECT * FROM company WHERE email = ?";
            checkStmt = con.prepareStatement(checkQuery);
            checkStmt.setString(1, email);
            ResultSet rs = checkStmt.executeQuery();

            if (rs.next()) {
                response.sendRedirect("companyRegister.html?error=Email Already Registered");
                return;
            }

            // Insert new company with 'Pending' status
            String insertQuery = "INSERT INTO company (name, email, contact, password, status) VALUES (?, ?, ?, ?, 'Pending')";
            insertStmt = con.prepareStatement(insertQuery);
            insertStmt.setString(1, name);
            insertStmt.setString(2, email);
            insertStmt.setString(3, contact);
            insertStmt.setString(4, password);

            int rowsInserted = insertStmt.executeUpdate();

            if (rowsInserted > 0) {
                response.sendRedirect("companyRegister.html?success=Registration Successful! Wait for Admin Approval");
            } else {
                response.sendRedirect("companyRegister.html?error=Registration Failed");
            }

        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("companyRegister.html?error=Something Went Wrong");

        } finally {
            try {
                if (checkStmt != null) checkStmt.close();
                if (insertStmt != null) insertStmt.close();
                if (con != null) con.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }
}
