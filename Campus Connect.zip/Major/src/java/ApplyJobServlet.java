

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/ApplyJobServlet")
public class ApplyJobServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String jobId = request.getParameter("jobId");
        String studentName = request.getParameter("studentName");
        String studentEmail = request.getParameter("studentEmail");
        String resume = request.getParameter("resume");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/major", "root", "mahi");

            PreparedStatement ps = con.prepareStatement("INSERT INTO job_applications (job_id, student_name, student_email, resume) VALUES (?, ?, ?, ?)");
            ps.setString(1, jobId);
            ps.setString(2, studentName);
            ps.setString(3, studentEmail);
            ps.setString(4, resume);

            int result = ps.executeUpdate();
            if (result > 0) {
                response.getWriter().println("Application submitted successfully!");
            } else {
                response.getWriter().println("Failed to submit application.");
            }

            ps.close();
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("Error: " + e.getMessage());
        }
    }
}