


import java.io.IOException;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/CompanyLoginServlet")
public class CompanyLoginServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver"); // Ensure driver is loaded
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/major", "root", "mahi");

            String query = "SELECT * FROM company WHERE email=? AND password=? AND status='Approved'";
            ps = con.prepareStatement(query);
            ps.setString(1, email);
            ps.setString(2, password);
            rs = ps.executeQuery();

            if (rs.next()) {
                HttpSession session = request.getSession();
                session.setAttribute("companyEmail", email);
                response.sendRedirect("companyDashboard.jsp");
            } else {
                response.sendRedirect("companyLogin.html?error=Invalid Credentials or Not Approved");
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("companyLogin.html?error=Database Error");
        } finally {
            try {
                if (rs != null) rs.close();
                if (ps != null) ps.close();
                if (con != null) con.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }
}
