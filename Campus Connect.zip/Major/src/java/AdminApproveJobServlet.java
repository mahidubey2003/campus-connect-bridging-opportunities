

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/AdminApproveJobServlet")
public class AdminApproveJobServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int jobId = Integer.parseInt(request.getParameter("jobId"));
        String action = request.getParameter("action");

        String newStatus = action.equals("approve") ? "Approved" : "Rejected";

        try {
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/major", "root", "mahi");
            PreparedStatement ps = con.prepareStatement("UPDATE jobs SET status = ? WHERE id = ?");
            ps.setString(1, newStatus);
            ps.setInt(2, jobId);
            ps.executeUpdate();

            response.sendRedirect("adminPanel.jsp?success=Job " + newStatus);
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("adminPanel.jsp?error=Something went wrong");
        }
    }
}