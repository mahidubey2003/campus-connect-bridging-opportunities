import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/StudentRegisterServlet")
public class StudentRegisterServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private static final String DB_URL = "jdbc:mysql://localhost:3306/major";
    private static final String DB_USER = "root";
    private static final String DB_PASS = "mahi";

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String contact = request.getParameter("contact");
        String password = request.getParameter("password");

        Connection conn = null;
        PreparedStatement stmt = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);

            // Insert into student table with status 'PENDING' (Waiting for Admin Approval)
            String query = "INSERT INTO student (name, email, contact, password, status) VALUES (?, ?, ?, ?, 'PENDING')";
            stmt = conn.prepareStatement(query);
            stmt.setString(1, name);
            stmt.setString(2, email);
            stmt.setString(3, contact);
            stmt.setString(4, password);

            int rows = stmt.executeUpdate();

            if (rows > 0) {
                out.println("<script>alert('Registration Successful! Wait for Admin Approval.'); window.location.href='studentRegister.html';</script>");
            } else {
                out.println("<script>alert('Registration Failed! Try Again.'); window.location.href='studentRegister.html';</script>");
            }

        } catch (Exception e) {
            out.println("<script>alert('Error: " + e.getMessage() + "'); window.location.href='studentRegister.html';</script>");
            e.printStackTrace();
        }
    }
}
