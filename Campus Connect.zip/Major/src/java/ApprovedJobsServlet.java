

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.logging.Level;
import java.util.logging.Logger;

@WebServlet("/ApprovedJobsServlet")
public class ApprovedJobsServlet extends HttpServlet {
    
    private static final Logger LOGGER = Logger.getLogger(ApprovedJobsServlet.class.getName());

    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        JSONArray jobArray = new JSONArray();

        try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/major", "root", "mahi");
             PreparedStatement ps = con.prepareStatement("SELECT id, title, location, salary FROM applied_jobs WHERE status='Approved'");
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                JSONObject job = new JSONObject();
                job.put("id", rs.getInt("id"));
                job.put("title", rs.getString("title"));
                job.put("location", rs.getString("location"));
                job.put("salary", rs.getString("salary"));
                jobArray.put(job);
            }

            LOGGER.log(Level.INFO, "Approved Jobs: {0}", jobArray.toString());
            out.print(jobArray.toString());

        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Error fetching approved jobs", e);
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            JSONObject errorObj = new JSONObject();
            errorObj.put("error", "Internal Server Error");
            out.print(errorObj.toString());
        } finally {
            out.flush();
            out.close();
        }
    }
}
